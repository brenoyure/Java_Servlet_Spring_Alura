package br.com.alura.jdbc.dao;

import java.sql.Connection;
import java.sql.SQLException;

public interface TrataSQLExceptionNasDAOs {

	default void trataSQLException(Connection connection, SQLException sqlException) {
	    System.err.println("---x---- INÍCIO do TRATA SQL EXCEPTION METHOD ---x--- " + this.getClass().getSimpleName());
	    System.err.println("SQL STATE: " + sqlException.getSQLState());
		System.err.println("Error Code: " + sqlException.getErrorCode());

		System.err.println("----- BEGIN OF STACK TRACE -------");
		sqlException.printStackTrace();
		System.err.println("----- END OF STACK TRACE -------");

		System.err.println("---x---- FIM do TRATA SQL EXCEPTION METHOD ---x--- " + this.getClass().getSimpleName());
	}

}
