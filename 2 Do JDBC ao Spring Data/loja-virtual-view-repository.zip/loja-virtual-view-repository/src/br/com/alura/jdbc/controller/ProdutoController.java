package br.com.alura.jdbc.controller;

import java.util.List;

import br.com.alura.jdbc.dao.ProdutoDAO;
import br.com.alura.jdbc.dao.TrataSQLExceptionNasDAOs;
import br.com.alura.jdbc.factory.ConnectionFactory;
import br.com.alura.jdbc.modelo.Produto;

public class ProdutoController implements TrataSQLExceptionNasDAOs {

	private ProdutoDAO produtoDAO;
	
	public ProdutoController() {
		
		this.produtoDAO = new ProdutoDAO(new ConnectionFactory().recuperarConexao());
		
	}
	
	public void deletar(Integer id) {
		this.produtoDAO.deletar(id);
		System.out.println("Deletando produto");
	}

	public void salvar(Produto produto) {
		this.produtoDAO.salvarComCategoria(produto);
		System.out.println("Salvando produto");
	}

	public List<Produto> listar() {
		System.out.println("Listando Produtos");
		return this.produtoDAO.listar();
	}

	public void alterar(String nome, String descricao, Integer id) {
		this.produtoDAO.alterar(nome, descricao, id);
	}
}
